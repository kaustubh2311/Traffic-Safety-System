<?php
function e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string {
    return BASE_URL . ($path === '' ? '/' : '/' . ltrim($path, '/'));
}

function redirect(string $path): never {
    header('Location: ' . url($path));
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
    $posted = $_POST['csrf_token'] ?? '';
    if (!is_string($posted) || !hash_equals(csrf_token(), $posted)) {
        http_response_code(419);
        exit('Your form session expired. Go back, refresh the page, and try again.');
    }
}

function flash(string $key, ?string $message = null): ?string {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }
    $value = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $value;
}

function current_admin(): ?array {
    return isset($_SESSION['admin']) && is_array($_SESSION['admin']) ? $_SESSION['admin'] : null;
}

function require_admin(): void {
    if (!current_admin()) {
        flash('error', 'Please sign in to access the authority area.');
        redirect('admin/login.php');
    }
}

function format_date(?string $date): string {
    if (!$date) return '—';
    $timestamp = strtotime($date);
    return $timestamp ? date('d M Y, h:i A', $timestamp) : '—';
}

function status_class(string $status): string {
    return match ($status) {
        'Submitted' => 'status-submitted',
        'Under Review' => 'status-review',
        'Verified' => 'status-verified',
        'Rejected' => 'status-rejected',
        'Closed' => 'status-closed',
        default => 'status-submitted',
    };
}

function violation_types(): array {
    return [
        'Speeding',
        'Red-light violation',
        'Wrong-side driving',
        'Illegal parking',
        'Helmet / seat-belt violation',
        'Using a mobile phone while driving',
        'Blocking a pedestrian crossing',
        'Dangerous / reckless driving',
        'Other',
    ];
}
