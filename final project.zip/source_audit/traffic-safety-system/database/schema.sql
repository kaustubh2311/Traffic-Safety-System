-- Team 6: Intelligent Traffic Violation Reporting and Road Safety Management System
-- Import this file in phpMyAdmin. The database is created if your MySQL user has permission.
CREATE DATABASE IF NOT EXISTS traffic_safety_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE traffic_safety_db;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','officer') NOT NULL DEFAULT 'officer',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reports (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reference_no VARCHAR(24) NOT NULL UNIQUE,
    reporter_name VARCHAR(100) NOT NULL,
    reporter_email VARCHAR(190) NOT NULL,
    vehicle_number VARCHAR(15) NOT NULL,
    violation_type VARCHAR(80) NOT NULL,
    location_text VARCHAR(255) NOT NULL,
    incident_at DATETIME NULL,
    description TEXT NOT NULL,
    evidence_path VARCHAR(255) NULL,
    status ENUM('Submitted','Under Review','Verified','Rejected','Closed') NOT NULL DEFAULT 'Submitted',
    officer_notes TEXT NULL,
    penalty_amount DECIMAL(10,2) NULL COMMENT 'Illustrative prototype estimate only; not an official fine',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_reports_status_created (status, created_at),
    INDEX idx_reports_email_ref (reporter_email, reference_no),
    INDEX idx_reports_vehicle (vehicle_number),
    INDEX idx_reports_violation (violation_type),
    INDEX idx_reports_location (location_text)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS report_status_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_id BIGINT UNSIGNED NOT NULL,
    old_status ENUM('Submitted','Under Review','Verified','Rejected','Closed') NULL,
    new_status ENUM('Submitted','Under Review','Verified','Rejected','Closed') NOT NULL,
    notes TEXT NULL,
    changed_by INT UNSIGNED NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_history_report FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE,
    CONSTRAINT fk_history_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_history_report_time (report_id, changed_at)
) ENGINE=InnoDB;
