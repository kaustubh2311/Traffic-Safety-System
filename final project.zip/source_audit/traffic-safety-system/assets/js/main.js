document.addEventListener('DOMContentLoaded', () => {
    const menuButton = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.main-nav');
    if (menuButton && nav) {
        menuButton.addEventListener('click', () => {
            const open = nav.classList.toggle('is-open');
            menuButton.setAttribute('aria-expanded', String(open));
        });
    }

    const description = document.getElementById('description');
    const count = document.getElementById('description-count');
    if (description && count) {
        const updateCount = () => { count.textContent = String(description.value.length); };
        description.addEventListener('input', updateCount);
        updateCount();
    }

    document.querySelectorAll('[data-copy]').forEach((button) => {
        button.addEventListener('click', async () => {
            const value = button.getAttribute('data-copy') || '';
            try {
                await navigator.clipboard.writeText(value);
                const original = button.textContent;
                button.textContent = 'Copied!';
                window.setTimeout(() => { button.textContent = original; }, 1600);
            } catch (_) {
                window.prompt('Copy this reference number:', value);
            }
        });
    });

    document.querySelectorAll('[data-confirm]').forEach((element) => {
        element.addEventListener('click', (event) => {
            const message = element.getAttribute('data-confirm') || 'Continue?';
            if (!window.confirm(message)) event.preventDefault();
        });
    });
});
